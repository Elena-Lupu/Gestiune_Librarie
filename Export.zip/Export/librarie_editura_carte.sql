-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: librarie
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `editura_carte`
--

DROP TABLE IF EXISTS `editura_carte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `editura_carte` (
  `ID_Editura` int NOT NULL,
  `ID_Carte` int NOT NULL,
  `ID_UserEdit` int DEFAULT NULL,
  `Data_UserEdit` date NOT NULL,
  `An_Aparitie` int NOT NULL,
  `Pret` float NOT NULL,
  `ExemplareVandute_An` int NOT NULL,
  `Cod_Carte` varchar(30) NOT NULL,
  PRIMARY KEY (`ID_Editura`,`ID_Carte`),
  KEY `fk_edituracarte_carte_idx` (`ID_Carte`),
  KEY `fk_edituracarte_utilizator` (`ID_UserEdit`),
  CONSTRAINT `fk_edituracarte_carte` FOREIGN KEY (`ID_Carte`) REFERENCES `carti` (`ID_Carte`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_edituracarte_editura` FOREIGN KEY (`ID_Editura`) REFERENCES `edituri` (`ID_Editura`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_edituracarte_utilizator` FOREIGN KEY (`ID_UserEdit`) REFERENCES `utilizatori` (`ID_Utilizator`) ON DELETE SET NULL ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `editura_carte`
--

LOCK TABLES `editura_carte` WRITE;
/*!40000 ALTER TABLE `editura_carte` DISABLE KEYS */;
INSERT INTO `editura_carte` VALUES (1,23,NULL,'2022-11-19',1996,30,4,'456-09-12'),(1,31,1,'2022-11-19',2009,25,70,'978-973-675-720-4'),(8,26,1,'2022-11-19',1978,10,5,'4658-89-1-456'),(8,28,1,'2022-12-10',1993,14,21,'973-601-099-6'),(8,31,1,'2022-12-10',1997,20,50,'5678-8987-2345'),(8,35,1,'2022-12-10',1971,14,28,'345-34-5454-48'),(10,42,1,'2023-01-02',2000,12,100,'64-4873-38'),(11,29,1,'2022-11-19',1974,22,30,'366-2422-544-7'),(11,30,1,'2022-11-19',1998,40,35,'443-5345-45-78'),(12,33,1,'2022-11-19',1991,32,100,'973-34-0220-6'),(12,34,1,'2022-11-19',1992,28,70,'973-34-0216-8'),(12,40,1,'2023-01-02',1999,30,12,'43567-9863-24');
/*!40000 ALTER TABLE `editura_carte` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-02 23:33:55
